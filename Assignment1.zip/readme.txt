The files should be read as follow:
First the source code with the comments 
Then the UI in this file.
To run the UI open UI > src > main > kotlin > main.kt ( preferably opening it with intelliJ)
After building the code and running it the user face will allow the user to inter the width of the table and positions of the home.
